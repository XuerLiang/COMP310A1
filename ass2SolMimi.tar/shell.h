// public functions

// returns TRUE (1) if parsed successfully, otherwise FALSE (0)
int parse(char buf[], char arg0[], char arg1[], char arg2[]);
int prompt(char buffer[]);

// returns error code from processing a shell command
int shell();
