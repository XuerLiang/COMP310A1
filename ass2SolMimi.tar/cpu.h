void initCPU();
void setCPU(FILE *PC);
int runCPU(int quanta);
