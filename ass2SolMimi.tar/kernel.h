int myinit(FILE *p);
void scheduler();
