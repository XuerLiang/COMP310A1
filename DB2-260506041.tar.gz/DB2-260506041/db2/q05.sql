SELECT DISTINCT b.bid, b.title
FROM book b, loan l
WHERE l.mid = 11111114 AND l.bid = b.bid AND l.bid IN (SELECT DISTINCT bid FROM loan WHERE mid = 11111118) 
ORDER BY b.bid;
