SELECT b.bid, b.title
FROM book b
WHERE b.publisher = 'Vintage' AND EXISTS (SELECT l.bid FROM loan l WHERE l.mid = 11111111 AND l.bid = b.bid)
ORDER BY b.bid;

