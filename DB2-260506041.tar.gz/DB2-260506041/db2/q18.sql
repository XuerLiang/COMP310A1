SELECT b.bid, COALESCE(numloans, 0) numloans 
FROM
(
SELECT bid, COUNT(*) numloans
FROM loan
WHERE fine IS NOT NULL
GROUP BY bid
) a 
RIGHT OUTER JOIN
(
SELECT bid
FROM book
) b
ON a.bid = b.bid
ORDER BY b.bid
;

