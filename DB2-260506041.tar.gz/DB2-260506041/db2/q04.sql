SELECT b.bid, b.title, l.fine
FROM book b, loan l
WHERE l.mid = 11111111 AND b.bid = l.bid AND NOT l.fine = 0.00
ORDER BY b.bid;
