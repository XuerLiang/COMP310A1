SELECT DISTINCT b.bid, b.title
FROM book b, copy c
WHERE b.bid = c.bid AND NOT EXISTS (SELECT l.bid FROM loan l WHERE l.bid = b.bid)
ORDER BY b.bid;
