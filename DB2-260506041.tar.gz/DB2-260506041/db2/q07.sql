SELECT bid, title
FROM book
WHERE publisher = 'Vintage' AND bid IN (SELECT bid FROM loan WHERE mid = 11111111)
ORDER BY bid;
