SELECT *
FROM copy
WHERE edition = 2 or edition = 3
ORDER BY bid, cid;
