SELECT t.status, t.numloans/s.nummems as avgloans
FROM
(
SELECT m.status as status, COUNT(*) as numloans
FROM member m, loan l
WHERE m.mid = l.mid AND l.fine > 0.00
GROUP BY m.status
) t,
(
SELECT status, COUNT(*) as nummems
FROM member
GROUP BY status
) s
WHERE t.status = s.status
ORDER BY t.status;

