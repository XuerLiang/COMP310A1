SELECT x.c/y.ct avgloans
FROM
(SELECT COUNT(*) c FROM loan) x,
(SELECT COUNT(*) ct FROM member) y 
; 
