SELECT m.mid, m.mname
FROM member m
WHERE m.mid IN (SELECT mid FROM loan WHERE fine > 0.00 GROUP BY mid HAVING COUNT(*) >= 3)
ORDER BY m.mid;
