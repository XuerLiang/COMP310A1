SELECT DISTINCT b.bid, b.title
FROM book b, loan l
WHERE l.mid = 11111111 AND b.bid = l.bid
ORDER BY b.bid;
