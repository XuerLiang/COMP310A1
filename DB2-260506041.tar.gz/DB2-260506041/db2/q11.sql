SELECT COUNT(*) nummembers
FROM member;
