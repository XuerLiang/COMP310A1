SELECT m.mid, SUM(l.fine) totalfine
FROM member m, loan l
WHERE m.status = 'REGULAR' AND m.mid = l.mid
GROUP BY m.mid
HAVING SUM(l.fine) > (SELECT AVG(sumfine) FROM (SELECT SUM(fine) sumfine FROM loan GROUP BY mid) t)
ORDER BY SUM(l.fine) DESC;
