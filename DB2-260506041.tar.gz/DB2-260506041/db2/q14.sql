SELECT bid, COUNT(*) numloans
FROM loan
GROUP BY bid
ORDER BY numloans DESC, bid;
