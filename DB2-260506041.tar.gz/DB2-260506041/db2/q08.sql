SELECT DISTINCT  b.bid, b.title
FROM book b JOIN loan l
ON b.bid = l.bid AND b.publisher = 'Vintage' AND l.mid = 11111111
ORDER BY b.bid;
