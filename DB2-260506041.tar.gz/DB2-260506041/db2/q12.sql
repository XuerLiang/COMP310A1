SELECT COUNT(DISTINCT m.mid) nummembers 
FROM member m, loan l
WHERE m.mid = l.mid AND l.fine > 0.00;
