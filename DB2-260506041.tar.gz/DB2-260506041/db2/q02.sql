SELECT DISTINCT bid 
FROM copy
WHERE edition = 3 AND bid NOT IN (SELECT bid FROM copy WHERE edition = 2)
ORDER BY bid;
