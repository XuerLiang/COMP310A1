
CREATE VIEW loans (bid, numloans) as
SELECT l.bid, COUNT(*)
FROM loan l, member m
WHERE l.mid = m.mid AND m.status = 'STUDENT'
GROUP BY l.bid;

SELECT bid, numloans
FROM loans
WHERE numloans = (SELECT MAX(numloans) FROM loans);

