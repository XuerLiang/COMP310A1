(SELECT bid, COUNT(*) numloans
FROM loan
WHERE fine IS NOT NULL
GROUP BY bid
UNION
SELECT bid, 0
FROM book
WHERE bid NOT IN (SELECT bid FROM loan)
)
ORDER BY bid
;
