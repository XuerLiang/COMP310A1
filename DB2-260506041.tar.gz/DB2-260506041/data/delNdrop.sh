db2 -t -v <<-END 2>&1 | tee delNdrop.log
CONNECT TO cs421;

DROP TABLE loan;
DROP TABLE member;
DROP TABLE copy;
DROP TABLE book;

QUIT;
END
